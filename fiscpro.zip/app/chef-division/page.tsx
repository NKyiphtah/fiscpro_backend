"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Building2, TrendingUp, Users, DollarSign, Target, AlertTriangle, Download } from "lucide-react"

// Ajouter les imports nécessaires en haut du fichier
import { ProtectedRoute } from "@/components/protected-route"
import { UserMenu } from "@/components/user-menu"

// Données consolidées pour tous les centres
const statsGlobales = {
  totalCentres: 3,
  totalContribuables: 156,
  montantOrdonnanceTotal: 285000,
  montantRecouvreTotale: 261500,
  tauxRecouvrementGlobal: 92,
  retardatairesTotal: 23,
}

const performanceParCentre = [
  {
    centre: "Centre A",
    contribuables: 45,
    ordonnance: 85000,
    recouvre: 78500,
    taux: 92,
    retardataires: 8,
  },
  {
    centre: "Centre B",
    contribuables: 62,
    ordonnance: 125000,
    recouvre: 118000,
    taux: 94,
    retardataires: 7,
  },
  {
    centre: "Centre C",
    contribuables: 49,
    ordonnance: 75000,
    recouvre: 65000,
    taux: 87,
    retardataires: 8,
  },
]

const evolutionMensuelle = [
  { mois: "Oct", centreA: 72000, centreB: 98000, centreC: 58000 },
  { mois: "Nov", centreA: 76000, centreB: 105000, centreC: 62000 },
  { mois: "Déc", centreA: 80000, centreB: 112000, centreC: 68000 },
  { mois: "Jan", centreA: 82000, centreB: 115000, centreC: 70000 },
  { mois: "Fév", centreA: 78500, centreB: 118000, centreC: 65000 },
]

const performanceParImpotGlobal = [
  { type: "ICM", total: 125000, pourcentage: 44 },
  { type: "IRL", total: 85000, pourcentage: 30 },
  { type: "IF", total: 45000, pourcentage: 16 },
  { type: "Vignettes", total: 28500, pourcentage: 10 },
]

// Envelopper le contenu dans ProtectedRoute et ajouter UserMenu dans le header
export default function ChefDivisionDashboard() {
  const [activeTab, setActiveTab] = useState("vue-ensemble")
  const [selectedPeriode, setSelectedPeriode] = useState("2024-02")

  const exportRapportGlobal = (format: string) => {
    console.log(`Export rapport global en ${format}`)
  }

  return (
    <ProtectedRoute allowedRoles={["Chef_Division"]}>
      <div className="min-h-screen bg-slate-50">
        {/* Header Chef de Division */}
        <header className="bg-purple-900 text-white p-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">Interface Chef de Division</h1>
                <p className="text-purple-200">Vue consolidée - Tous les centres</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-sm text-purple-200">Connecté en tant que</p>
                  <p className="font-semibold">Marie TSHISEKEDI - Chef de Division</p>
                </div>
                <UserMenu />
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="vue-ensemble">Vue d'Ensemble</TabsTrigger>
              <TabsTrigger value="centres">Par Centre</TabsTrigger>
              <TabsTrigger value="impots">Par Impôt</TabsTrigger>
              <TabsTrigger value="rapports">Rapports</TabsTrigger>
            </TabsList>

            {/* Vue d'Ensemble */}
            <TabsContent value="vue-ensemble" className="space-y-6">
              {/* KPIs Globaux */}
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Centres</p>
                        <p className="text-2xl font-bold">{statsGlobales.totalCentres}</p>
                      </div>
                      <Building2 className="h-8 w-8 text-purple-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Contribuables</p>
                        <p className="text-2xl font-bold">{statsGlobales.totalContribuables}</p>
                      </div>
                      <Users className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Ordonnancé</p>
                        <p className="text-xl font-bold">${statsGlobales.montantOrdonnanceTotal.toLocaleString()}</p>
                      </div>
                      <DollarSign className="h-8 w-8 text-yellow-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Recouvré</p>
                        <p className="text-xl font-bold text-green-600">
                          ${statsGlobales.montantRecouvreTotale.toLocaleString()}
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Taux Global</p>
                        <p className="text-2xl font-bold text-blue-600">{statsGlobales.tauxRecouvrementGlobal}%</p>
                      </div>
                      <Target className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Retardataires</p>
                        <p className="text-2xl font-bold text-red-600">{statsGlobales.retardatairesTotal}</p>
                      </div>
                      <AlertTriangle className="h-8 w-8 text-red-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Graphiques de synthèse */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Évolution Mensuelle par Centre</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={evolutionMensuelle}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="mois" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                        <Line type="monotone" dataKey="centreA" stroke="#3b82f6" strokeWidth={2} name="Centre A" />
                        <Line type="monotone" dataKey="centreB" stroke="#10b981" strokeWidth={2} name="Centre B" />
                        <Line type="monotone" dataKey="centreC" stroke="#f59e0b" strokeWidth={2} name="Centre C" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Répartition par Type d'Impôt</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={performanceParImpotGlobal}
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="total"
                          label={({ type, pourcentage }) => `${type} ${pourcentage}%`}
                        >
                          {performanceParImpotGlobal.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={["#3b82f6", "#10b981", "#f59e0b", "#ef4444"][index]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Comparaison des centres */}
              <Card>
                <CardHeader>
                  <CardTitle>Performance Comparative des Centres</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={performanceParCentre}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="centre" />
                      <YAxis />
                      <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                      <Bar dataKey="ordonnance" fill="#3b82f6" name="Ordonnancé" />
                      <Bar dataKey="recouvre" fill="#10b981" name="Recouvré" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Performance par Centre */}
            <TabsContent value="centres">
              <Card>
                <CardHeader>
                  <CardTitle>Analyse Détaillée par Centre</CardTitle>
                  <CardDescription>Performance et statistiques de chaque centre</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Centre</TableHead>
                        <TableHead>Contribuables</TableHead>
                        <TableHead>Ordonnancé</TableHead>
                        <TableHead>Recouvré</TableHead>
                        <TableHead>Taux</TableHead>
                        <TableHead>Retardataires</TableHead>
                        <TableHead>Performance</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {performanceParCentre.map((centre, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{centre.centre}</TableCell>
                          <TableCell>{centre.contribuables}</TableCell>
                          <TableCell>${centre.ordonnance.toLocaleString()}</TableCell>
                          <TableCell className="text-green-600 font-semibold">
                            ${centre.recouvre.toLocaleString()}
                          </TableCell>
                          <TableCell className="font-semibold">{centre.taux}%</TableCell>
                          <TableCell>
                            <Badge variant="destructive">{centre.retardataires}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={centre.taux >= 90 ? "default" : centre.taux >= 85 ? "secondary" : "destructive"}
                              className={
                                centre.taux >= 90
                                  ? "bg-green-100 text-green-800"
                                  : centre.taux >= 85
                                    ? "bg-yellow-100 text-yellow-800"
                                    : ""
                              }
                            >
                              {centre.taux >= 90 ? "Excellent" : centre.taux >= 85 ? "Bon" : "À améliorer"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Performance par Impôt */}
            <TabsContent value="impots">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Globale par Type d'Impôt</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Type d'Impôt</TableHead>
                          <TableHead>Montant Total</TableHead>
                          <TableHead>Pourcentage</TableHead>
                          <TableHead>Centre A</TableHead>
                          <TableHead>Centre B</TableHead>
                          <TableHead>Centre C</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {performanceParImpotGlobal.map((impot, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{impot.type}</TableCell>
                            <TableCell className="font-semibold">${impot.total.toLocaleString()}</TableCell>
                            <TableCell>{impot.pourcentage}%</TableCell>
                            <TableCell>$45,000</TableCell>
                            <TableCell>$52,000</TableCell>
                            <TableCell>$28,000</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Rapports */}
            <TabsContent value="rapports">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Rapports Consolidés</CardTitle>
                    <CardDescription>Export des données globales et comparatives</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="font-semibold">Rapports Disponibles</h3>
                        <div className="space-y-2">
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportGlobal("PDF")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Rapport Consolidé (PDF)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportGlobal("Excel")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Performance par Centre (Excel)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportGlobal("PDF")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Analyse par Impôt (PDF)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportGlobal("Excel")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Données Complètes (Excel)
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="font-semibold">Statistiques Rapides</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between p-3 bg-blue-50 rounded-lg">
                            <span>Meilleur Centre:</span>
                            <span className="font-semibold">Centre B (94%)</span>
                          </div>
                          <div className="flex justify-between p-3 bg-green-50 rounded-lg">
                            <span>Meilleur Impôt:</span>
                            <span className="font-semibold">ICM (44%)</span>
                          </div>
                          <div className="flex justify-between p-3 bg-yellow-50 rounded-lg">
                            <span>À Améliorer:</span>
                            <span className="font-semibold">Centre C (87%)</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  )
}
