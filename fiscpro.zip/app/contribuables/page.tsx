"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, Edit, Eye, FileText } from "lucide-react"

interface Contribuable {
  id: string
  nom: string
  postnom: string
  prenom: string
  adresse: string
  email: string
  telephone: string
  centre: string
  statut: "Actif" | "Inactif" | "Suspendu"
  dernierPaiement: string
  montantDu: number
}

const contribuablesData: Contribuable[] = [
  {
    id: "CONT-001",
    nom: "MUKENDI",
    postnom: "KABONGO",
    prenom: "Jean",
    adresse: "Av. Lumumba, Kinshasa",
    email: "jean.mukendi@email.com",
    telephone: "+243 81 234 5678",
    centre: "Centre A",
    statut: "Actif",
    dernierPaiement: "2024-01-15",
    montantDu: 1500,
  },
  {
    id: "CONT-002",
    nom: "TSHISEKEDI",
    postnom: "MBUYI",
    prenom: "Marie",
    adresse: "Bd. du 30 Juin, Kinshasa",
    email: "marie.tshisekedi@email.com",
    telephone: "+243 82 345 6789",
    centre: "Centre B",
    statut: "Actif",
    dernierPaiement: "2024-01-20",
    montantDu: 2300,
  },
  {
    id: "CONT-003",
    nom: "KABILA",
    postnom: "NGOY",
    prenom: "Pierre",
    adresse: "Av. Kasavubu, Kinshasa",
    email: "pierre.kabila@email.com",
    telephone: "+243 83 456 7890",
    centre: "Centre A",
    statut: "Suspendu",
    dernierPaiement: "2023-12-10",
    montantDu: 5600,
  },
]

export default function ContribuablesPage() {
  const [contribuables, setContribuables] = useState<Contribuable[]>(contribuablesData)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCentre, setSelectedCentre] = useState("tous")
  const [selectedStatut, setSelectedStatut] = useState("tous")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newContribuable, setNewContribuable] = useState({
    nom: "",
    postnom: "",
    prenom: "",
    adresse: "",
    email: "",
    telephone: "",
    centre: "",
  })

  const filteredContribuables = contribuables.filter((contrib) => {
    const matchesSearch =
      contrib.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contrib.postnom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contrib.prenom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contrib.email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCentre = selectedCentre === "tous" || contrib.centre === selectedCentre
    const matchesStatut = selectedStatut === "tous" || contrib.statut === selectedStatut

    return matchesSearch && matchesCentre && matchesStatut
  })

  const handleAddContribuable = () => {
    const newId = `CONT-${String(contribuables.length + 1).padStart(3, "0")}`
    const contribuable: Contribuable = {
      ...newContribuable,
      id: newId,
      statut: "Actif",
      dernierPaiement: new Date().toISOString().split("T")[0],
      montantDu: 0,
    }

    setContribuables([...contribuables, contribuable])
    setNewContribuable({
      nom: "",
      postnom: "",
      prenom: "",
      adresse: "",
      email: "",
      telephone: "",
      centre: "",
    })
    setIsAddDialogOpen(false)
  }

  const getStatutBadge = (statut: string) => {
    switch (statut) {
      case "Actif":
        return <Badge className="bg-green-100 text-green-800">Actif</Badge>
      case "Inactif":
        return <Badge variant="secondary">Inactif</Badge>
      case "Suspendu":
        return <Badge variant="destructive">Suspendu</Badge>
      default:
        return <Badge variant="outline">{statut}</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white p-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold">Gestion des Contribuables</h1>
          <p className="text-slate-300">Gérer les informations des contribuables</p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Filtres et actions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Recherche et Filtres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher un contribuable..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={selectedCentre} onValueChange={setSelectedCentre}>
                <SelectTrigger>
                  <SelectValue placeholder="Tous les centres" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tous">Tous les centres</SelectItem>
                  <SelectItem value="Centre A">Centre A</SelectItem>
                  <SelectItem value="Centre B">Centre B</SelectItem>
                  <SelectItem value="Centre C">Centre C</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedStatut} onValueChange={setSelectedStatut}>
                <SelectTrigger>
                  <SelectValue placeholder="Tous les statuts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tous">Tous les statuts</SelectItem>
                  <SelectItem value="Actif">Actif</SelectItem>
                  <SelectItem value="Inactif">Inactif</SelectItem>
                  <SelectItem value="Suspendu">Suspendu</SelectItem>
                </SelectContent>
              </Select>

              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Nouveau Contribuable
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Ajouter un Nouveau Contribuable</DialogTitle>
                    <DialogDescription>Remplissez les informations du contribuable</DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="nom">Nom</Label>
                      <Input
                        id="nom"
                        value={newContribuable.nom}
                        onChange={(e) => setNewContribuable({ ...newContribuable, nom: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="postnom">Post-nom</Label>
                      <Input
                        id="postnom"
                        value={newContribuable.postnom}
                        onChange={(e) => setNewContribuable({ ...newContribuable, postnom: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="prenom">Prénom</Label>
                      <Input
                        id="prenom"
                        value={newContribuable.prenom}
                        onChange={(e) => setNewContribuable({ ...newContribuable, prenom: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="centre">Centre</Label>
                      <Select
                        value={newContribuable.centre}
                        onValueChange={(value) => setNewContribuable({ ...newContribuable, centre: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner un centre" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Centre A">Centre A</SelectItem>
                          <SelectItem value="Centre B">Centre B</SelectItem>
                          <SelectItem value="Centre C">Centre C</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2">
                      <Label htmlFor="adresse">Adresse</Label>
                      <Input
                        id="adresse"
                        value={newContribuable.adresse}
                        onChange={(e) => setNewContribuable({ ...newContribuable, adresse: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newContribuable.email}
                        onChange={(e) => setNewContribuable({ ...newContribuable, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="telephone">Téléphone</Label>
                      <Input
                        id="telephone"
                        value={newContribuable.telephone}
                        onChange={(e) => setNewContribuable({ ...newContribuable, telephone: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 mt-4">
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Annuler
                    </Button>
                    <Button onClick={handleAddContribuable}>Ajouter</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold">{contribuables.length}</div>
              <p className="text-sm text-muted-foreground">Total Contribuables</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-600">
                {contribuables.filter((c) => c.statut === "Actif").length}
              </div>
              <p className="text-sm text-muted-foreground">Actifs</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-red-600">
                {contribuables.filter((c) => c.statut === "Suspendu").length}
              </div>
              <p className="text-sm text-muted-foreground">Suspendus</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold">
                ${contribuables.reduce((sum, c) => sum + c.montantDu, 0).toLocaleString()}
              </div>
              <p className="text-sm text-muted-foreground">Montant Total Dû</p>
            </CardContent>
          </Card>
        </div>

        {/* Tableau des contribuables */}
        <Card>
          <CardHeader>
            <CardTitle>Liste des Contribuables ({filteredContribuables.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Nom Complet</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Centre</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Montant Dû</TableHead>
                  <TableHead>Dernier Paiement</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContribuables.map((contribuable) => (
                  <TableRow key={contribuable.id}>
                    <TableCell className="font-medium">{contribuable.id}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {contribuable.nom} {contribuable.postnom} {contribuable.prenom}
                        </div>
                        <div className="text-sm text-muted-foreground">{contribuable.adresse}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{contribuable.email}</div>
                        <div className="text-muted-foreground">{contribuable.telephone}</div>
                      </div>
                    </TableCell>
                    <TableCell>{contribuable.centre}</TableCell>
                    <TableCell>{getStatutBadge(contribuable.statut)}</TableCell>
                    <TableCell className="font-medium">${contribuable.montantDu.toLocaleString()}</TableCell>
                    <TableCell>{contribuable.dernierPaiement}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <FileText className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
