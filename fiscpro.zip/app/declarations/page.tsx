"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calculator, FileText, DollarSign, Car, Building, Coins } from "lucide-react"

export default function DeclarationsPage() {
  const [activeTab, setActiveTab] = useState("icm")
  const [icmData, setIcmData] = useState({
    contribuable: "",
    superficie: "",
    localite: "",
    numeroDepot: "",
    periode: "",
    montantCalcule: 0,
  })

  const [irlData, setIrlData] = useState({
    contribuable: "",
    loyerMensuel: "",
    periode: "",
    montantCalcule: 0,
  })

  const [ifData, setIfData] = useState({
    contribuable: "",
    superficie: "",
    typePropriete: "",
    valeurLocative: "",
    montantCalcule: 0,
  })

  const [vignetteData, setVignetteData] = useState({
    contribuable: "",
    typeVehicule: "",
    cv: "",
    poids: "",
    typePersonne: "",
    montantVignette: 0,
    montantTSCR: 0,
    montantTotal: 0,
  })

  // Calcul automatique ICM
  const calculateICM = (superficie: number) => {
    if (superficie < 1) return superficie * 10
    if (superficie <= 5) return superficie * 15
    return superficie * 20
  }

  // Calcul automatique IRL
  const calculateIRL = (loyerMensuel: number) => {
    return loyerMensuel * 0.22 // 22% du loyer mensuel
  }

  // Calcul automatique Vignette
  const calculateVignette = (cv: number, typePersonne: string) => {
    let vignette = 0
    const tscr = 50 // TSCR fixe

    if (cv >= 1 && cv <= 5) {
      vignette = typePersonne === "morale" ? 54 : 27
    } else if (cv >= 6 && cv <= 10) {
      vignette = typePersonne === "morale" ? 81 : 40.5
    } else if (cv >= 11 && cv <= 15) {
      vignette = typePersonne === "morale" ? 108 : 54
    } else if (cv > 15) {
      vignette = typePersonne === "morale" ? 135 : 67.5
    }

    return { vignette, tscr, total: vignette + tscr }
  }

  const handleICMCalculation = () => {
    const superficie = Number.parseFloat(icmData.superficie) || 0
    const montant = calculateICM(superficie)
    setIcmData({ ...icmData, montantCalcule: montant })
  }

  const handleIRLCalculation = () => {
    const loyer = Number.parseFloat(irlData.loyerMensuel) || 0
    const montant = calculateIRL(loyer)
    setIrlData({ ...irlData, montantCalcule: montant })
  }

  const handleVignetteCalculation = () => {
    const cv = Number.parseFloat(vignetteData.cv) || 0
    const { vignette, tscr, total } = calculateVignette(cv, vignetteData.typePersonne)
    setVignetteData({
      ...vignetteData,
      montantVignette: vignette,
      montantTSCR: tscr,
      montantTotal: total,
    })
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white p-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold">Déclarations Fiscales</h1>
          <p className="text-slate-300">Saisie et gestion des déclarations d'impôts</p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="icm" className="flex items-center gap-2">
              <Coins className="h-4 w-4" />
              ICM
            </TabsTrigger>
            <TabsTrigger value="irl" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              IRL
            </TabsTrigger>
            <TabsTrigger value="if" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              IF
            </TabsTrigger>
            <TabsTrigger value="vignette" className="flex items-center gap-2">
              <Car className="h-4 w-4" />
              Vignettes
            </TabsTrigger>
            <TabsTrigger value="notes" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Notes Tax
            </TabsTrigger>
          </TabsList>

          {/* ICM - Impôt sur les Concessions Minières */}
          <TabsContent value="icm">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Coins className="h-5 w-5" />
                  Impôt sur les Concessions Minières (ICM)
                </CardTitle>
                <CardDescription>Calcul automatique basé sur la superficie en hectares</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="icm-contribuable">Contribuable</Label>
                      <Select
                        value={icmData.contribuable}
                        onValueChange={(value) => setIcmData({ ...icmData, contribuable: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner un contribuable" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="CONT-001">MUKENDI KABONGO Jean</SelectItem>
                          <SelectItem value="CONT-002">TSHISEKEDI MBUYI Marie</SelectItem>
                          <SelectItem value="CONT-003">KABILA NGOY Pierre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="icm-superficie">Superficie (Ha)</Label>
                      <Input
                        id="icm-superficie"
                        type="number"
                        step="0.01"
                        value={icmData.superficie}
                        onChange={(e) => setIcmData({ ...icmData, superficie: e.target.value })}
                        placeholder="Entrer la superficie en hectares"
                      />
                    </div>

                    <div>
                      <Label htmlFor="icm-localite">Localité</Label>
                      <Input
                        id="icm-localite"
                        value={icmData.localite}
                        onChange={(e) => setIcmData({ ...icmData, localite: e.target.value })}
                        placeholder="Localité de la concession"
                      />
                    </div>

                    <div>
                      <Label htmlFor="icm-depot">Numéro de Dépôt</Label>
                      <Input
                        id="icm-depot"
                        value={icmData.numeroDepot}
                        onChange={(e) => setIcmData({ ...icmData, numeroDepot: e.target.value })}
                        placeholder="DEP-2024-001"
                      />
                    </div>

                    <div>
                      <Label htmlFor="icm-periode">Période</Label>
                      <Select
                        value={icmData.periode}
                        onValueChange={(value) => setIcmData({ ...icmData, periode: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner la période" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="2024-01">Janvier 2024</SelectItem>
                          <SelectItem value="2024-02">Février 2024</SelectItem>
                          <SelectItem value="2024-03">Mars 2024</SelectItem>
                          <SelectItem value="2024-04">Avril 2024</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button onClick={handleICMCalculation} className="w-full">
                      <Calculator className="h-4 w-4 mr-2" />
                      Calculer l'ICM
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <Card className="bg-blue-50 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg">Barème ICM</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>{"< 1 Ha"}</span>
                            <span className="font-semibold">10 $/Ha</span>
                          </div>
                          <div className="flex justify-between">
                            <span>1 - 5 Ha</span>
                            <span className="font-semibold">15 $/Ha</span>
                          </div>
                          <div className="flex justify-between">
                            <span>{"> 5 Ha"}</span>
                            <span className="font-semibold">20 $/Ha</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {icmData.montantCalcule > 0 && (
                      <Card className="bg-green-50 border-green-200">
                        <CardHeader>
                          <CardTitle className="text-lg text-green-800">Montant Calculé</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold text-green-600">${icmData.montantCalcule.toFixed(2)}</div>
                          <p className="text-sm text-green-700 mt-2">Superficie: {icmData.superficie} Ha</p>
                        </CardContent>
                      </Card>
                    )}

                    <Button variant="outline" className="w-full bg-transparent">
                      Enregistrer la Déclaration
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* IRL - Impôt sur le Revenu Locatif */}
          <TabsContent value="irl">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  Impôt sur le Revenu Locatif (IRL)
                </CardTitle>
                <CardDescription>22% du loyer mensuel déclaré</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="irl-contribuable">Contribuable</Label>
                      <Select
                        value={irlData.contribuable}
                        onValueChange={(value) => setIrlData({ ...irlData, contribuable: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner un contribuable" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="CONT-001">MUKENDI KABONGO Jean</SelectItem>
                          <SelectItem value="CONT-002">TSHISEKEDI MBUYI Marie</SelectItem>
                          <SelectItem value="CONT-003">KABILA NGOY Pierre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="irl-loyer">Loyer Mensuel ($)</Label>
                      <Input
                        id="irl-loyer"
                        type="number"
                        step="0.01"
                        value={irlData.loyerMensuel}
                        onChange={(e) => setIrlData({ ...irlData, loyerMensuel: e.target.value })}
                        placeholder="Montant du loyer mensuel"
                      />
                    </div>

                    <div>
                      <Label htmlFor="irl-periode">Période</Label>
                      <Select
                        value={irlData.periode}
                        onValueChange={(value) => setIrlData({ ...irlData, periode: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner la période" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="2024-01">Janvier 2024</SelectItem>
                          <SelectItem value="2024-02">Février 2024</SelectItem>
                          <SelectItem value="2024-03">Mars 2024</SelectItem>
                          <SelectItem value="2024-04">Avril 2024</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button onClick={handleIRLCalculation} className="w-full">
                      <Calculator className="h-4 w-4 mr-2" />
                      Calculer l'IRL
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <Card className="bg-blue-50 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg">Calcul IRL</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm">
                          <p className="mb-2">
                            Taux d'imposition: <span className="font-semibold">22%</span>
                          </p>
                          <p>Formule: Loyer mensuel × 22%</p>
                        </div>
                      </CardContent>
                    </Card>

                    {irlData.montantCalcule > 0 && (
                      <Card className="bg-green-50 border-green-200">
                        <CardHeader>
                          <CardTitle className="text-lg text-green-800">Montant Calculé</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-3xl font-bold text-green-600">${irlData.montantCalcule.toFixed(2)}</div>
                          <p className="text-sm text-green-700 mt-2">Loyer: ${irlData.loyerMensuel} × 22%</p>
                        </CardContent>
                      </Card>
                    )}

                    <Button variant="outline" className="w-full bg-transparent">
                      Enregistrer la Déclaration
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vignettes */}
          <TabsContent value="vignette">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Car className="h-5 w-5" />
                  Vignettes et TSCR
                </CardTitle>
                <CardDescription>Impôt sur les véhicules automobiles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="vignette-contribuable">Contribuable</Label>
                      <Select
                        value={vignetteData.contribuable}
                        onValueChange={(value) => setVignetteData({ ...vignetteData, contribuable: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner un contribuable" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="CONT-001">MUKENDI KABONGO Jean</SelectItem>
                          <SelectItem value="CONT-002">TSHISEKEDI MBUYI Marie</SelectItem>
                          <SelectItem value="CONT-003">KABILA NGOY Pierre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="vignette-type">Type de Véhicule</Label>
                      <Select
                        value={vignetteData.typeVehicule}
                        onValueChange={(value) => setVignetteData({ ...vignetteData, typeVehicule: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner le type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="voiture">Voiture</SelectItem>
                          <SelectItem value="camion">Camion</SelectItem>
                          <SelectItem value="moto">Moto</SelectItem>
                          <SelectItem value="bus">Bus</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="vignette-cv">Chevaux Vapeur (CV)</Label>
                      <Input
                        id="vignette-cv"
                        type="number"
                        value={vignetteData.cv}
                        onChange={(e) => setVignetteData({ ...vignetteData, cv: e.target.value })}
                        placeholder="Nombre de CV"
                      />
                    </div>

                    <div>
                      <Label htmlFor="vignette-personne">Type de Personne</Label>
                      <Select
                        value={vignetteData.typePersonne}
                        onValueChange={(value) => setVignetteData({ ...vignetteData, typePersonne: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner le type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="physique">Personne Physique</SelectItem>
                          <SelectItem value="morale">Personne Morale</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button onClick={handleVignetteCalculation} className="w-full">
                      <Calculator className="h-4 w-4 mr-2" />
                      Calculer Vignette + TSCR
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {vignetteData.montantTotal > 0 && (
                      <Card className="bg-green-50 border-green-200">
                        <CardHeader>
                          <CardTitle className="text-lg text-green-800">Montants Calculés</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex justify-between">
                            <span>Vignette:</span>
                            <span className="font-semibold">${vignetteData.montantVignette}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>TSCR:</span>
                            <span className="font-semibold">${vignetteData.montantTSCR}</span>
                          </div>
                          <hr />
                          <div className="flex justify-between text-lg">
                            <span className="font-semibold">Total:</span>
                            <span className="font-bold text-green-600">${vignetteData.montantTotal}</span>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    <Card className="bg-blue-50 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg">Barème Vignettes</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <div className="grid grid-cols-3 gap-2 font-semibold">
                            <span>CV</span>
                            <span>Physique</span>
                            <span>Morale</span>
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            <span>1-5</span>
                            <span>$27</span>
                            <span>$54</span>
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            <span>6-10</span>
                            <span>$40.5</span>
                            <span>$81</span>
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            <span>11-15</span>
                            <span>$54</span>
                            <span>$108</span>
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            <span>{"> 15"}</span>
                            <span>$67.5</span>
                            <span>$135</span>
                          </div>
                          <p className="text-xs text-blue-700 mt-2">+ TSCR: $50 fixe</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Button variant="outline" className="w-full bg-transparent">
                      Enregistrer la Déclaration
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* IF - Impôt Foncier */}
          <TabsContent value="if">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Impôt Foncier (IF)
                </CardTitle>
                <CardDescription>Impôt sur les propriétés bâties et non bâties</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <FileText className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Formulaire IF en développement</h3>
                  <p className="text-muted-foreground">
                    Le formulaire pour l'Impôt Foncier sera disponible prochainement.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notes de Taxation */}
          <TabsContent value="notes">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Notes de Taxation
                </CardTitle>
                <CardDescription>Recouvrement ponctuel divers</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="notes-type">Type d'Impôt</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner le type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ICM">ICM</SelectItem>
                          <SelectItem value="IRL">IRL</SelectItem>
                          <SelectItem value="IF">IF</SelectItem>
                          <SelectItem value="Vignettes">Vignettes</SelectItem>
                          <SelectItem value="Penalite">Pénalité</SelectItem>
                          <SelectItem value="Frais">Frais de dossier</SelectItem>
                          <SelectItem value="Autre">Autre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="notes-numero">Numéro de Note</Label>
                      <Input id="notes-numero" placeholder="NOTE-2024-001" />
                    </div>

                    <div>
                      <Label htmlFor="notes-bordereau">Numéro de Bordereau</Label>
                      <Input id="notes-bordereau" placeholder="BOR-2024-001" />
                    </div>

                    <div>
                      <Label htmlFor="notes-montant-ordonnance">Montant Ordonnancé ($)</Label>
                      <Input id="notes-montant-ordonnance" type="number" step="0.01" placeholder="Montant ordonnancé" />
                    </div>

                    <div>
                      <Label htmlFor="notes-montant">Montant Recouvré ($)</Label>
                      <Input
                        id="notes-montant"
                        type="number"
                        step="0.01"
                        placeholder="Montant effectivement recouvré"
                      />
                    </div>

                    <div>
                      <Label htmlFor="notes-banque">Banque</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner la banque" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="BCC">Banque Centrale du Congo</SelectItem>
                          <SelectItem value="Rawbank">Rawbank</SelectItem>
                          <SelectItem value="Equity">Equity Bank</SelectItem>
                          <SelectItem value="TMB">Trust Merchant Bank</SelectItem>
                          <SelectItem value="BCDC">BCDC</SelectItem>
                          <SelectItem value="Autre">Autre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button className="w-full">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Enregistrer la Note de Taxation
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <Card className="bg-blue-50 border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-lg">Information</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>Notes de Taxation :</strong>
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                            <li>Recouvrement ponctuel divers</li>
                            <li>Pénalités de retard</li>
                            <li>Frais de dossier</li>
                            <li>Régularisations</li>
                            <li>Autres recettes fiscales</li>
                          </ul>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-yellow-50 border-yellow-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-yellow-800">Rappel</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-yellow-700">
                          Assurez-vous que le numéro de bordereau correspond au document officiel de la banque.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
