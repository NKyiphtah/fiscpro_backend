"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Plus, Eye, Calculator, CheckCircle, Clock, AlertTriangle } from "lucide-react"

// Ajouter les imports nécessaires en haut du fichier
import { ProtectedRoute } from "@/components/protected-route"
import { UserMenu } from "@/components/user-menu"

// Données simulées pour l'encodeur
const mesDeclarations = [
  {
    id: 1,
    type: "ICM",
    contribuable: "MUKENDI KABONGO Jean",
    montant: 375.0,
    periode: "2024-02",
    statut: "Validé",
    dateCreation: "2024-02-15",
  },
  {
    id: 2,
    type: "IRL",
    contribuable: "TSHISEKEDI MBUYI Marie",
    montant: 484.0,
    periode: "2024-02",
    statut: "En attente",
    dateCreation: "2024-02-20",
  },
  {
    id: 3,
    type: "Vignette",
    contribuable: "KABILA NGOY Pierre",
    montant: 158.0,
    periode: "2024",
    statut: "Rejeté",
    dateCreation: "2024-02-18",
  },
]

const contribuablesDisponibles = [
  { id: "CONT-001", nom: "MUKENDI KABONGO Jean", centre: "Centre A" },
  { id: "CONT-002", nom: "TSHISEKEDI MBUYI Marie", centre: "Centre A" },
  { id: "CONT-003", nom: "KABILA NGOY Pierre", centre: "Centre A" },
  { id: "CONT-004", nom: "MBUYI TSHALA Joseph", centre: "Centre A" },
]

// Envelopper le contenu dans ProtectedRoute et ajouter UserMenu dans le header
export default function EncodeurDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [selectedPeriode, setSelectedPeriode] = useState("2024-02")

  const statsEncodeur = {
    totalDeclarations: mesDeclarations.length,
    validees: mesDeclarations.filter((d) => d.statut === "Validé").length,
    enAttente: mesDeclarations.filter((d) => d.statut === "En attente").length,
    rejetees: mesDeclarations.filter((d) => d.statut === "Rejeté").length,
  }

  const getStatutBadge = (statut: string) => {
    switch (statut) {
      case "Validé":
        return (
          <Badge className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Validé
          </Badge>
        )
      case "En attente":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">
            <Clock className="h-3 w-3 mr-1" />
            En attente
          </Badge>
        )
      case "Rejeté":
        return (
          <Badge variant="destructive">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Rejeté
          </Badge>
        )
      default:
        return <Badge variant="outline">{statut}</Badge>
    }
  }

  return (
    <ProtectedRoute allowedRoles={["Encodeur"]}>
      <div className="min-h-screen bg-slate-50">
        {/* Header Encodeur */}
        <header className="bg-blue-900 text-white p-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">Interface Encodeur</h1>
                <p className="text-blue-200">Centre A - Saisie des déclarations fiscales</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-sm text-blue-200">Connecté en tant que</p>
                  <p className="font-semibold">Joseph MBUYI - Encodeur</p>
                </div>
                <UserMenu />
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="dashboard">Tableau de Bord</TabsTrigger>
              <TabsTrigger value="nouvelle">Nouvelle Déclaration</TabsTrigger>
              <TabsTrigger value="mes-declarations">Mes Déclarations</TabsTrigger>
              <TabsTrigger value="contribuables">Contribuables</TabsTrigger>
            </TabsList>

            {/* Dashboard Encodeur */}
            <TabsContent value="dashboard" className="space-y-6">
              {/* Statistiques personnelles */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Mes Déclarations</p>
                        <p className="text-2xl font-bold">{statsEncodeur.totalDeclarations}</p>
                      </div>
                      <FileText className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Validées</p>
                        <p className="text-2xl font-bold text-green-600">{statsEncodeur.validees}</p>
                      </div>
                      <CheckCircle className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">En Attente</p>
                        <p className="text-2xl font-bold text-yellow-600">{statsEncodeur.enAttente}</p>
                      </div>
                      <Clock className="h-8 w-8 text-yellow-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Rejetées</p>
                        <p className="text-2xl font-bold text-red-600">{statsEncodeur.rejetees}</p>
                      </div>
                      <AlertTriangle className="h-8 w-8 text-red-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Actions rapides */}
              <Card>
                <CardHeader>
                  <CardTitle>Actions Rapides</CardTitle>
                  <CardDescription>Accès direct aux fonctionnalités principales</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Button className="h-20 flex flex-col gap-2" onClick={() => setActiveTab("nouvelle")}>
                      <Plus className="h-6 w-6" />
                      Nouvelle ICM
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col gap-2 bg-transparent"
                      onClick={() => setActiveTab("nouvelle")}
                    >
                      <Plus className="h-6 w-6" />
                      Nouvelle IRL
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col gap-2 bg-transparent"
                      onClick={() => setActiveTab("nouvelle")}
                    >
                      <Plus className="h-6 w-6" />
                      Nouvelle Vignette
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col gap-2 bg-transparent"
                      onClick={() => setActiveTab("mes-declarations")}
                    >
                      <Eye className="h-6 w-6" />
                      Voir Mes Déclarations
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Dernières déclarations */}
              <Card>
                <CardHeader>
                  <CardTitle>Mes Dernières Déclarations</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Contribuable</TableHead>
                        <TableHead>Montant</TableHead>
                        <TableHead>Période</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mesDeclarations.slice(0, 5).map((declaration) => (
                        <TableRow key={declaration.id}>
                          <TableCell>
                            <Badge variant="outline">{declaration.type}</Badge>
                          </TableCell>
                          <TableCell>{declaration.contribuable}</TableCell>
                          <TableCell className="font-semibold">${declaration.montant.toLocaleString()}</TableCell>
                          <TableCell>{declaration.periode}</TableCell>
                          <TableCell>{getStatutBadge(declaration.statut)}</TableCell>
                          <TableCell>{declaration.dateCreation}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Nouvelle Déclaration */}
            <TabsContent value="nouvelle">
              <Card>
                <CardHeader>
                  <CardTitle>Nouvelle Déclaration</CardTitle>
                  <CardDescription>Sélectionner le type de déclaration à encoder</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-blue-500">
                      <CardContent className="p-6 text-center">
                        <Calculator className="h-12 w-12 mx-auto mb-4 text-blue-500" />
                        <h3 className="font-semibold mb-2">ICM</h3>
                        <p className="text-sm text-muted-foreground">Impôt sur les Concessions Minières</p>
                      </CardContent>
                    </Card>

                    <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-green-500">
                      <CardContent className="p-6 text-center">
                        <Calculator className="h-12 w-12 mx-auto mb-4 text-green-500" />
                        <h3 className="font-semibold mb-2">IRL</h3>
                        <p className="text-sm text-muted-foreground">Impôt sur le Revenu Locatif</p>
                      </CardContent>
                    </Card>

                    <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-purple-500">
                      <CardContent className="p-6 text-center">
                        <Calculator className="h-12 w-12 mx-auto mb-4 text-purple-500" />
                        <h3 className="font-semibold mb-2">Vignettes</h3>
                        <p className="text-sm text-muted-foreground">Impôt sur les Véhicules</p>
                      </CardContent>
                    </Card>

                    <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-yellow-500">
                      <CardContent className="p-6 text-center">
                        <Calculator className="h-12 w-12 mx-auto mb-4 text-yellow-500" />
                        <h3 className="font-semibold mb-2">Notes Tax</h3>
                        <p className="text-sm text-muted-foreground">Notes de Taxation</p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Mes Déclarations */}
            <TabsContent value="mes-declarations">
              <Card>
                <CardHeader>
                  <CardTitle>Mes Déclarations</CardTitle>
                  <CardDescription>Liste de toutes mes déclarations encodées</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-4">
                    <Select value={selectedPeriode} onValueChange={setSelectedPeriode}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Sélectionner la période" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="tous">Toutes les périodes</SelectItem>
                        <SelectItem value="2024-02">Février 2024</SelectItem>
                        <SelectItem value="2024-01">Janvier 2024</SelectItem>
                        <SelectItem value="2023-12">Décembre 2023</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Contribuable</TableHead>
                        <TableHead>Montant</TableHead>
                        <TableHead>Période</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead>Date Création</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mesDeclarations.map((declaration) => (
                        <TableRow key={declaration.id}>
                          <TableCell className="font-medium">#{declaration.id}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{declaration.type}</Badge>
                          </TableCell>
                          <TableCell>{declaration.contribuable}</TableCell>
                          <TableCell className="font-semibold">${declaration.montant.toLocaleString()}</TableCell>
                          <TableCell>{declaration.periode}</TableCell>
                          <TableCell>{getStatutBadge(declaration.statut)}</TableCell>
                          <TableCell>{declaration.dateCreation}</TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Contribuables */}
            <TabsContent value="contribuables">
              <Card>
                <CardHeader>
                  <CardTitle>Contribuables - Centre A</CardTitle>
                  <CardDescription>Liste des contribuables de mon centre</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nom Complet</TableHead>
                        <TableHead>Centre</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {contribuablesDisponibles.map((contribuable) => (
                        <TableRow key={contribuable.id}>
                          <TableCell className="font-medium">{contribuable.id}</TableCell>
                          <TableCell>{contribuable.nom}</TableCell>
                          <TableCell>
                            <Badge variant="secondary">{contribuable.centre}</Badge>
                          </TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm">
                              <FileText className="h-4 w-4 mr-2" />
                              Générer Fiche
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  )
}
