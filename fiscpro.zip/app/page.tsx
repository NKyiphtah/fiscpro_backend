"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Shield, Users, BarChart3, FileText, Building2, Crown, Calculator } from "lucide-react"
import Link from "next/link"

const features = [
  {
    icon: Calculator,
    title: "Calculs Automatiques",
    description: "Calcul automatique des impôts ICM, IRL, IF et Vignettes selon les barèmes officiels",
    color: "text-blue-500",
  },
  {
    icon: Users,
    title: "Gestion des Contribuables",
    description: "Base de données complète des contribuables avec historique des paiements",
    color: "text-green-500",
  },
  {
    icon: BarChart3,
    title: "Rapports et Statistiques",
    description: "Tableaux de bord interactifs et rapports détaillés par centre et par impôt",
    color: "text-purple-500",
  },
  {
    icon: Shield,
    title: "Sécurité et Contrôle",
    description: "Système de rôles et permissions pour sécuriser l'accès aux données",
    color: "text-red-500",
  },
]

const roles = [
  {
    role: "Encodeur",
    icon: FileText,
    description: "Saisie des déclarations fiscales",
    color: "bg-blue-100 text-blue-800",
    href: "/auth/login?role=encodeur",
  },
  {
    role: "Chef de Centre",
    icon: Building2,
    description: "Gestion d'un centre fiscal",
    color: "bg-green-100 text-green-800",
    href: "/auth/login?role=chef-centre",
  },
  {
    role: "Chef de Division",
    icon: Users,
    description: "Supervision de plusieurs centres",
    color: "bg-purple-100 text-purple-800",
    href: "/auth/login?role=chef-division",
  },
  {
    role: "Direction",
    icon: Crown,
    description: "Vue stratégique globale",
    color: "bg-yellow-100 text-yellow-800",
    href: "/auth/login?role=direction",
  },
]

const stats = [
  { label: "Contribuables Enregistrés", value: "1,250+", icon: Users },
  { label: "Centres Fiscaux", value: "3", icon: Building2 },
  { label: "Types d'Impôts", value: "5", icon: FileText },
  { label: "Taux de Recouvrement", value: "92%", icon: BarChart3 },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">SGF-RDC</h1>
                <p className="text-sm text-gray-600">Système de Gestion Fiscale</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/auth/login">
                <Button variant="outline">Se Connecter</Button>
              </Link>
              <Link href="/auth/register">
                <Button>S'Inscrire</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <Badge className="mb-4 bg-blue-100 text-blue-800 px-4 py-2">République Démocratique du Congo</Badge>
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Système de Gestion
              <span className="text-blue-600 block">Fiscale Moderne</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Plateforme intégrée pour la gestion des recettes fiscales, le suivi des contribuables et l'optimisation du
              recouvrement des impôts en République Démocratique du Congo.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/auth/login">
              <Button size="lg" className="px-8 py-3">
                Accéder au Système
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="px-8 py-3 bg-transparent">
              Découvrir les Fonctionnalités
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-2">
                  <stat.icon className="h-8 w-8 text-blue-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Fonctionnalités Principales</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Un système complet pour moderniser la gestion fiscale et améliorer l'efficacité du recouvrement.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex justify-center mb-4">
                    <feature.icon className={`h-12 w-12 ${feature.color}`} />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Roles Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Accès par Rôle</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Chaque utilisateur dispose d'une interface adaptée à ses responsabilités et permissions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {roles.map((roleItem, index) => (
              <Link key={index} href={roleItem.href}>
                <Card className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                  <CardContent className="p-6 text-center">
                    <div className="flex justify-center mb-4">
                      <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                        <roleItem.icon className="h-8 w-8 text-gray-600" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{roleItem.role}</h3>
                    <p className="text-gray-600 text-sm mb-4">{roleItem.description}</p>
                    <Badge className={roleItem.color}>{roleItem.role}</Badge>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Prêt à Moderniser la Gestion Fiscale ?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Rejoignez le système de gestion fiscale moderne de la RDC et optimisez vos processus de recouvrement.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/login">
              <Button size="lg" variant="secondary" className="px-8 py-3">
                Se Connecter Maintenant
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="px-8 py-3 text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              Demander une Démonstration
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Shield className="h-5 w-5 text-white" />
                </div>
                <span className="text-lg font-bold">SGF-RDC</span>
              </div>
              <p className="text-gray-400 text-sm">Système de Gestion Fiscale de la République Démocratique du Congo</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Fonctionnalités</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Gestion des Contribuables</li>
                <li>Calculs Automatiques</li>
                <li>Rapports et Statistiques</li>
                <li>Suivi des Paiements</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Rôles</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Encodeur</li>
                <li>Chef de Centre</li>
                <li>Chef de Division</li>
                <li>Direction</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Documentation</li>
                <li>Formation</li>
                <li>Assistance Technique</li>
                <li>Contact</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 Système de Gestion Fiscale - République Démocratique du Congo. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
