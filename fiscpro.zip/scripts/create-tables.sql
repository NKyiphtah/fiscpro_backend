-- Création des tables pour le système de gestion fiscale

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS utilisateurs (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('Encodeur', 'Chef_Centre', 'Chef_Division', 'Direction', 'Controleur')),
    centre VARCHAR(100),
    actif BOOLEAN DEFAULT true,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des contribuables
CREATE TABLE IF NOT EXISTS contribuables (
    id SERIAL PRIMARY KEY,
    code_contribuable VARCHAR(20) UNIQUE NOT NULL,
    nom VARCHAR(100) NOT NULL,
    postnom VARCHAR(100),
    prenom VARCHAR(100),
    adresse TEXT,
    email VARCHAR(150),
    telephone VARCHAR(20),
    centre VARCHAR(100) NOT NULL,
    statut VARCHAR(20) DEFAULT 'Actif' CHECK (statut IN ('Actif', 'Inactif', 'Suspendu')),
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table ICM (Impôt sur les Concessions Minières)
CREATE TABLE IF NOT EXISTS icm (
    id SERIAL PRIMARY KEY,
    contribuable_id INTEGER REFERENCES contribuables(id),
    numero_depot VARCHAR(50) NOT NULL,
    localite VARCHAR(100) NOT NULL,
    superficie DECIMAL(10,2) NOT NULL,
    taux_hectare DECIMAL(10,2) NOT NULL,
    impot_du DECIMAL(12,2) NOT NULL,
    periode VARCHAR(7) NOT NULL, -- Format: YYYY-MM
    date_declaration TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut_paiement VARCHAR(20) DEFAULT 'En_attente' CHECK (statut_paiement IN ('En_attente', 'Paye', 'Partiel', 'Retard')),
    montant_paye DECIMAL(12,2) DEFAULT 0,
    date_paiement TIMESTAMP,
    encodeur_id INTEGER REFERENCES utilisateurs(id)
);

-- Table IRL (Impôt sur le Revenu Locatif)
CREATE TABLE IF NOT EXISTS irl (
    id SERIAL PRIMARY KEY,
    contribuable_id INTEGER REFERENCES contribuables(id),
    loyer_mensuel DECIMAL(12,2) NOT NULL,
    taux_imposition DECIMAL(5,2) DEFAULT 22.00,
    impot_du DECIMAL(12,2) NOT NULL,
    periode VARCHAR(7) NOT NULL,
    date_declaration TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut_paiement VARCHAR(20) DEFAULT 'En_attente',
    montant_paye DECIMAL(12,2) DEFAULT 0,
    date_paiement TIMESTAMP,
    encodeur_id INTEGER REFERENCES utilisateurs(id)
);

-- Table IF (Impôt Foncier)
CREATE TABLE IF NOT EXISTS impot_foncier (
    id SERIAL PRIMARY KEY,
    contribuable_id INTEGER REFERENCES contribuables(id),
    type_propriete VARCHAR(50) NOT NULL CHECK (type_propriete IN ('Batie', 'Non_batie')),
    superficie DECIMAL(10,2),
    valeur_locative DECIMAL(12,2),
    taux_imposition DECIMAL(5,2),
    impot_du DECIMAL(12,2) NOT NULL,
    periode VARCHAR(7) NOT NULL,
    date_declaration TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut_paiement VARCHAR(20) DEFAULT 'En_attente',
    montant_paye DECIMAL(12,2) DEFAULT 0,
    date_paiement TIMESTAMP,
    encodeur_id INTEGER REFERENCES utilisateurs(id)
);

-- Table Vignettes
CREATE TABLE IF NOT EXISTS vignettes (
    id SERIAL PRIMARY KEY,
    contribuable_id INTEGER REFERENCES contribuables(id),
    type_vehicule VARCHAR(50) NOT NULL,
    chevaux_vapeur INTEGER NOT NULL,
    poids_vehicule DECIMAL(8,2),
    type_personne VARCHAR(20) NOT NULL CHECK (type_personne IN ('Physique', 'Morale')),
    montant_vignette DECIMAL(10,2) NOT NULL,
    montant_tscr DECIMAL(10,2) NOT NULL,
    montant_total DECIMAL(10,2) NOT NULL,
    periode VARCHAR(4) NOT NULL, -- Année
    date_declaration TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut_paiement VARCHAR(20) DEFAULT 'En_attente',
    montant_paye DECIMAL(12,2) DEFAULT 0,
    date_paiement TIMESTAMP,
    encodeur_id INTEGER REFERENCES utilisateurs(id)
);

-- Table Notes de Taxation
CREATE TABLE IF NOT EXISTS notes_taxation (
    id SERIAL PRIMARY KEY,
    contribuable_id INTEGER REFERENCES contribuables(id),
    motif TEXT NOT NULL,
    montant DECIMAL(12,2) NOT NULL,
    date_echeance DATE NOT NULL,
    periode VARCHAR(7) NOT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut_paiement VARCHAR(20) DEFAULT 'En_attente',
    montant_paye DECIMAL(12,2) DEFAULT 0,
    date_paiement TIMESTAMP,
    encodeur_id INTEGER REFERENCES utilisateurs(id)
);

-- Table des paiements
CREATE TABLE IF NOT EXISTS paiements (
    id SERIAL PRIMARY KEY,
    type_impot VARCHAR(20) NOT NULL CHECK (type_impot IN ('ICM', 'IRL', 'IF', 'Vignette', 'Note_Tax')),
    declaration_id INTEGER NOT NULL,
    contribuable_id INTEGER REFERENCES contribuables(id),
    montant DECIMAL(12,2) NOT NULL,
    devise VARCHAR(3) DEFAULT 'USD' CHECK (devise IN ('USD', 'CDF')),
    mode_paiement VARCHAR(50),
    reference_paiement VARCHAR(100),
    banque VARCHAR(100),
    date_paiement TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    preuve_paiement TEXT, -- URL ou chemin vers le fichier
    validateur_id INTEGER REFERENCES utilisateurs(id),
    date_validation TIMESTAMP
);

-- Table d'audit/historique
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    utilisateur_id INTEGER REFERENCES utilisateurs(id),
    action VARCHAR(100) NOT NULL,
    table_affectee VARCHAR(50) NOT NULL,
    enregistrement_id INTEGER,
    anciennes_valeurs JSONB,
    nouvelles_valeurs JSONB,
    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    adresse_ip INET
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_contribuables_centre ON contribuables(centre);
CREATE INDEX IF NOT EXISTS idx_icm_periode ON icm(periode);
CREATE INDEX IF NOT EXISTS idx_icm_statut ON icm(statut_paiement);
CREATE INDEX IF NOT EXISTS idx_irl_periode ON irl(periode);
CREATE INDEX IF NOT EXISTS idx_paiements_date ON paiements(date_paiement);
CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_log(date_action);
