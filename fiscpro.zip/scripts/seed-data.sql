-- Insertion des données de test

-- Insertion des utilisateurs
INSERT INTO utilisateurs (nom, email, mot_de_passe, role, centre) VALUES
('Admin Système', 'admin@finances.cd', '$2b$10$hashedpassword', 'Direction', NULL),
('Jean MUKENDI', 'j.mukendi@centre-a.cd', '$2b$10$hashedpassword', 'Chef_Centre', 'Centre A'),
('Marie TSHISEKEDI', 'm.tshisekedi@centre-b.cd', '$2b$10$hashedpassword', 'Chef_Centre', 'Centre B'),
('Pierre KABILA', 'p.kabila@centre-c.cd', '$2b$10$hashedpassword', 'Chef_Centre', 'Centre C'),
('Joseph MBUYI', 'j.mbuyi@encodeur.cd', '$2b$10$hashedpassword', 'Encodeur', 'Centre A'),
('Sarah NGOY', 's.ngoy@encodeur.cd', '$2b$10$hashedpassword', 'Encodeur', 'Centre B');

-- Insertion des contribuables
INSERT INTO contribuables (code_contribuable, nom, postnom, prenom, adresse, email, telephone, centre) VALUES
('CONT-001', 'MUKENDI', 'KABONGO', 'Jean', 'Av. Lumumba, Kinshasa', 'jean.mukendi@email.com', '+243 81 234 5678', 'Centre A'),
('CONT-002', 'TSHISEKEDI', 'MBUYI', 'Marie', 'Bd. du 30 Juin, Kinshasa', 'marie.tshisekedi@email.com', '+243 82 345 6789', 'Centre B'),
('CONT-003', 'KABILA', 'NGOY', 'Pierre', 'Av. Kasavubu, Kinshasa', 'pierre.kabila@email.com', '+243 83 456 7890', 'Centre A'),
('CONT-004', 'MBUYI', 'TSHALA', 'Joseph', 'Av. Kasa-Vubu, Kinshasa', 'joseph.mbuyi@email.com', '+243 84 567 8901', 'Centre C'),
('CONT-005', 'NGOY', 'KASONGO', 'Sarah', 'Bd. Lumumba, Kinshasa', 'sarah.ngoy@email.com', '+243 85 678 9012', 'Centre B');

-- Insertion des déclarations ICM
INSERT INTO icm (contribuable_id, numero_depot, localite, superficie, taux_hectare, impot_du, periode, encodeur_id) VALUES
(1, 'DEP-2024-001', 'Kolwezi', 2.5, 15.00, 37.50, '2024-01', 5),
(2, 'DEP-2024-002', 'Lubumbashi', 8.0, 20.00, 160.00, '2024-01', 6),
(3, 'DEP-2024-003', 'Likasi', 0.8, 10.00, 8.00, '2024-02', 5),
(4, 'DEP-2024-004', 'Kolwezi', 12.0, 20.00, 240.00, '2024-02', 6);

-- Insertion des déclarations IRL
INSERT INTO irl (contribuable_id, loyer_mensuel, impot_du, periode, encodeur_id) VALUES
(1, 1500.00, 330.00, '2024-01', 5),
(2, 2200.00, 484.00, '2024-01', 6),
(3, 1800.00, 396.00, '2024-02', 5),
(5, 2500.00, 550.00, '2024-02', 6);

-- Insertion des vignettes
INSERT INTO vignettes (contribuable_id, type_vehicule, chevaux_vapeur, type_personne, montant_vignette, montant_tscr, montant_total, periode, encodeur_id) VALUES
(1, 'Voiture', 8, 'Physique', 40.50, 50.00, 90.50, '2024', 5),
(2, 'Voiture', 12, 'Morale', 108.00, 50.00, 158.00, '2024', 6),
(3, 'Camion', 18, 'Morale', 135.00, 50.00, 185.00, '2024', 5),
(4, 'Voiture', 6, 'Physique', 40.50, 50.00, 90.50, '2024', 6);

-- Insertion des notes de taxation
INSERT INTO notes_taxation (contribuable_id, motif, montant, date_echeance, periode, encodeur_id) VALUES
(1, 'Pénalité de retard - ICM', 50.00, '2024-03-15', '2024-02', 5),
(3, 'Frais de dossier', 25.00, '2024-03-20', '2024-02', 5),
(4, 'Pénalité de retard - IRL', 75.00, '2024-03-25', '2024-02', 6);

-- Insertion des paiements
INSERT INTO paiements (type_impot, declaration_id, contribuable_id, montant, devise, mode_paiement, reference_paiement, banque, validateur_id) VALUES
('ICM', 1, 1, 37.50, 'USD', 'Virement', 'VIR-2024-001', 'Banque Centrale du Congo', 2),
('IRL', 1, 1, 330.00, 'USD', 'Espèces', 'ESP-2024-001', NULL, 2),
('Vignette', 1, 1, 90.50, 'USD', 'Chèque', 'CHQ-2024-001', 'Rawbank', 3),
('ICM', 2, 2, 160.00, 'USD', 'Virement', 'VIR-2024-002', 'Equity Bank', 3);

-- Mise à jour des statuts de paiement
UPDATE icm SET statut_paiement = 'Paye', montant_paye = impot_du, date_paiement = CURRENT_TIMESTAMP WHERE id IN (1, 2);
UPDATE irl SET statut_paiement = 'Paye', montant_paye = impot_du, date_paiement = CURRENT_TIMESTAMP WHERE id = 1;
UPDATE vignettes SET statut_paiement = 'Paye', montant_paye = montant_total, date_paiement = CURRENT_TIMESTAMP WHERE id = 1;

-- Insertion d'entrées d'audit
INSERT INTO audit_log (utilisateur_id, action, table_affectee, enregistrement_id, nouvelles_valeurs) VALUES
(5, 'INSERT', 'icm', 1, '{"numero_depot": "DEP-2024-001", "impot_du": 37.50}'),
(6, 'INSERT', 'irl', 1, '{"loyer_mensuel": 1500.00, "impot_du": 330.00}'),
(2, 'UPDATE', 'icm', 1, '{"statut_paiement": "Paye", "montant_paye": 37.50}');
