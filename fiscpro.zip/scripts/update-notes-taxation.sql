-- Script de mise à jour pour la table notes_taxation
-- Basé sur la structure réelle fournie

-- Vérifier si la table existe et la recréer si nécessaire
DROP TABLE IF EXISTS notes_taxation_backup;

-- Créer une sauvegarde si la table existe déjà
DO $$
BEGIN
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'notes_taxation') THEN
        CREATE TABLE notes_taxation_backup AS SELECT * FROM notes_taxation;
    END IF;
END
$$;

-- Supprimer l'ancienne table si elle existe
DROP TABLE IF EXISTS notes_taxation;

-- Créer la table avec la structure correcte
CREATE TABLE public.notes_taxation (
    id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    type_impot text,
    montant_ordonnace numeric,
    numero_note character varying,
    numero_bordereau character varying,
    banque text,
    montant numeric,
    CONSTRAINT notes_taxation_pkey PRIMARY KEY (id)
);

-- Insérer des données de test
INSERT INTO public.notes_taxation (type_impot, montant_ordonnace, numero_note, numero_bordereau, banque, montant) VALUES
('ICM', 1500.00, 'NOTE-2024-001', 'BOR-2024-001', 'Rawbank', 1500.00),
('Penalite', 250.00, 'NOTE-2024-002', 'BOR-2024-002', 'BCC', 200.00),
('Frais', 100.00, 'NOTE-2024-003', 'BOR-2024-003', 'Equity Bank', 100.00),
('IRL', 800.00, 'NOTE-2024-004', 'BOR-2024-004', 'TMB', 750.00),
('Vignettes', 158.00, 'NOTE-2024-005', 'BOR-2024-005', 'BCDC', 158.00),
('Penalite', 75.00, 'NOTE-2024-006', 'BOR-2024-006', 'Rawbank', 0.00),
('IF', 450.00, 'NOTE-2024-007', 'BOR-2024-007', 'BCC', 450.00),
('Frais', 50.00, 'NOTE-2024-008', 'BOR-2024-008', 'Equity Bank', 25.00);

-- Créer des index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_notes_taxation_type ON notes_taxation(type_impot);
CREATE INDEX IF NOT EXISTS idx_notes_taxation_date ON notes_taxation(created_at);
CREATE INDEX IF NOT EXISTS idx_notes_taxation_numero ON notes_taxation(numero_note);
CREATE INDEX IF NOT EXISTS idx_notes_taxation_banque ON notes_taxation(banque);

-- Ajouter des commentaires pour la documentation
COMMENT ON TABLE notes_taxation IS 'Table des notes de taxation pour les recouvrements ponctuels divers';
COMMENT ON COLUMN notes_taxation.type_impot IS 'Type d''impôt concerné (ICM, IRL, IF, Vignettes, Penalite, Frais)';
COMMENT ON COLUMN notes_taxation.montant_ordonnace IS 'Montant ordonnancé (avec faute de frappe dans le nom de colonne)';
COMMENT ON COLUMN notes_taxation.numero_note IS 'Numéro unique de la note de taxation';
COMMENT ON COLUMN notes_taxation.numero_bordereau IS 'Numéro du bordereau bancaire';
COMMENT ON COLUMN notes_taxation.banque IS 'Nom de la banque de recouvrement';
COMMENT ON COLUMN notes_taxation.montant IS 'Montant effectivement recouvré';
